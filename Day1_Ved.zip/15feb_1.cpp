#include <iostream>
using namespace std;

int main()
{
int i;

cout << "This is output.\n";
cout << "Enter i:";
cin >> i;
cout << i<< " squared is "<< i*i << "\n";

return 0;
}
